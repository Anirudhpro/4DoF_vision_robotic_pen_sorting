# Pens > 2025-07-03 5:58am
https://universe.roboflow.com/tbn-acjk2/pens-y8dxo

Provided by a Roboflow user
License: CC BY 4.0

